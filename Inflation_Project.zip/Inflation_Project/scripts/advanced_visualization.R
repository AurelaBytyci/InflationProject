# Load necessary libraries
library(ggplot2)
library(dplyr)
library(readr)

# Load cleaned dataset
filtered_global <- read_csv("data/cleaned_global_inflation.csv") %>%
  rename(Country = country_name)  # Rename for consistency with Basic visualizations

# Ensure the directory exists
dir.create("visuals/advanced", recursive = TRUE, showWarnings = FALSE)

# ------------------------------ #
# **1. Faceted Inflation Trends Over Time**
# ------------------------------ #
facet_plot <- ggplot(filtered_global, aes(x = Year, y = InflationRate, color = Country)) +
  geom_line(size = 1.2, alpha = 0.8) +
  facet_wrap(~ Country, scales = "free_y") +  # One country per panel
  labs(title = "Inflation Trends by Country Over Time",
       x = "Year", y = "Inflation Rate (%)") +
  theme_minimal()

ggsave("visuals/advanced/facet_trends.png", plot = facet_plot, width = 12, height = 8)

# ------------------------------ #
# **2. Inflation Heatmap**
# ------------------------------ #
heatmap_plot <- ggplot(filtered_global, aes(x = Year, y = Country, fill = InflationRate)) +
  geom_tile() +
  scale_fill_gradient(low = "blue", high = "red") +
  labs(title = "Inflation Heatmap by Country and Year",
       x = "Year", y = "Country", fill = "Inflation Rate") +
  theme_minimal()

ggsave("visuals/advanced/inflation_heatmap.png", plot = heatmap_plot, width = 10, height = 8)

# ------------------------------ #
# **3. Stacked Bar Chart of Country Contributions to Inflation**
# ------------------------------ #
stacked_bar_plot <- ggplot(filtered_global, aes(x = Year, y = InflationRate, fill = Country)) +
  geom_bar(stat = "identity") +
  labs(title = "Country Contributions to Global Inflation",
       x = "Year", y = "Inflation Rate (%)") +
  theme_minimal()

ggsave("visuals/advanced/stacked_inflation_contribution.png", plot = stacked_bar_plot, width = 12, height = 8)

# ------------------------------ #
# **4. Improved Inflation Boxplot (Filtered for Outliers)**
# ------------------------------ #
filtered_boxplot <- filtered_global %>% filter(InflationRate <= 100)  # Remove extreme inflation rates

boxplot_plot <- ggplot(filtered_boxplot, aes(x = reorder(Country, InflationRate, median), y = InflationRate, fill = Country)) +
  geom_boxplot(outlier.shape = NA) +  # Remove extreme outliers
  labs(title = "Distribution of Inflation Rates by Country",
       x = "Country", y = "Inflation Rate (%)") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, size = 8), 
        legend.position = "none")  # Rotate country labels

ggsave("visuals/advanced/inflation_boxplot.png", plot = boxplot_plot, width = 12, height = 8)

# ------------------------------ #
# **5. Improved Cumulative Inflation Chart (Top 10 Countries)**
# ------------------------------ #
cumulative_data <- filtered_global %>%
  group_by(Country) %>%
  arrange(Year) %>%
  mutate(Cumulative_Inflation = cumsum(InflationRate))

# Keep only top 10 countries with highest cumulative inflation
top_countries <- cumulative_data %>%
  group_by(Country) %>%
  summarize(Total_Inflation = sum(InflationRate, na.rm = TRUE)) %>%
  top_n(10, Total_Inflation) %>%
  pull(Country)

filtered_cumulative <- cumulative_data %>% filter(Country %in% top_countries)

cumulative_area_plot <- ggplot(filtered_cumulative, aes(x = Year, y = Cumulative_Inflation, fill = Country)) +
  geom_area(alpha = 0.7) +
  labs(title = "Cumulative Inflation Over Time (Top 10 Countries)",
       x = "Year", y = "Cumulative Inflation (%)") +
  theme_minimal()

ggsave("visuals/advanced/cumulative_inflation.png", plot = cumulative_area_plot, width = 12, height = 8)

# ------------------------------ #
# **6. Improved Inflation Scatter Plot (Filtered for Outliers)**
# ------------------------------ #
filtered_scatter <- filtered_global %>% filter(InflationRate <= 100)  # Remove extreme values

scatter_plot <- ggplot(filtered_scatter, aes(x = Year, y = InflationRate, color = Country)) +
  geom_point(alpha = 0.6) +
  labs(title = "Inflation Rates Over Time (Filtered)",
       x = "Year", y = "Inflation Rate (%)") +
  theme_minimal() +
  theme(legend.position = "none")  # Hide legend to reduce clutter

ggsave("visuals/advanced/inflation_scatter.png", plot = scatter_plot, width = 10, height = 8)

message("✅ Advanced visualizations saved in 'visuals/advanced/'\n")
