library(dplyr)
library(readr)

# Load datasets
filtered_global <- read_csv("data/cleaned_global_inflation.csv") %>%
  select(-indicator_name) %>%  # Remove unnecessary column
  rename(country_name = country_name)  # Ensuring consistent naming

filtered_wb <- read_csv("data/cleaned_world_bank_data.csv") %>%
  rename(country_name = `Country Name`)  # Fix column name for consistency

# Verify structure
print(head(filtered_global))
print(head(filtered_wb))

# Check column names to confirm changes
print(colnames(filtered_global))
print(colnames(filtered_wb))

View(global_data)
