# Inflation Trends and Analysis Project

## Project Overview
This project analyzes inflation trends across regions and time periods using datasets from:
- OECD Statistics
- Global Inflation Data
- World Bank Data

The analysis highlights inflation's impact on different regions and includes **interactive** and **static** visualizations created with R, `ggplot2`, and a **Shiny Dashboard**.

---

## Project Structure
The project is organized into the following folders:

- **`data/`**: Contains raw and cleaned datasets.
- **`visuals/basic/`**: Basic visualizations.
- **`visuals/advanced/`**: Advanced visualizations with enhanced clarity.
- **`scripts/`**: R scripts for data cleaning, visualization, and Shiny app.
- **`shiny_dashboard/`**: The interactive Shiny application.
- **`whitepaper/`**: The final white paper.
- **`projectdocumentation/`**: The project documentation.

---

## Requirements
To run the scripts, you'll need:
- R version 4.0 or above.
- The following R packages:
  - `ggplot2`
  - `dplyr`
  - `readr`
  - `tidyr`
  - `shiny`
  - `maps`

Install packages with:
```r
install.packages(c("ggplot2", "dplyr", "readr", "tidyr", "shiny", "maps"))
```

---

## How to Run the Project

### 1. Data Cleaning
Run the `data_cleaning.R` script to process raw data:
```bash
Rscript scripts/data_cleaning.R
```
- Outputs:
  - `cleaned_oecd_data.csv` (OECD inflation data)
  - `cleaned_global_inflation.csv` (Global inflation data)
  - `cleaned_world_bank_data.csv` (World Bank inflation data)

### 2. Visualization
Run the `visualization.R` script to generate basic visualizations:
```bash
Rscript scripts/visualization.R
```
- Outputs (saved in visuals/basic/):
  - `inflation_trends.png` (Line chart of inflation trends)
  - `regional_inflation_2000.png` (Bar chart for a single year)
  - `inflation_histogram.png` (Histogram of inflation rates)
  - `inflation_boxplot.png` (Boxplot of inflation distribution)
---
Run the advanced_visualization.R script to generate enhanced visualizations:
```bash
Rscript scripts/advanced_visualization.R
```
- Outputs (saved in visuals/advanced/):
   - `cumulative_inflation.png` (Stacked area chart of inflation)
   - `facet_trends.png` (Faceted trend lines by region)
   - `inflation_scatter.png` (Scatter plot of inflation rates)
   - `gdp_time_series.png `(GDP trend visualization)
   - `gdp_world_map.png` (Geographical GDP distribution)

### 3. Interactive Shiny Dashboard
To run the Shiny Dashboard, execute:
```bash
Rscript scripts/shiny_dashboard.R
```
- This launches a web-based interactive dashboard where users can:
   a. Filter inflation trends by year and region.
   b. View interactive charts with tooltips and dynamic elements.
   c. Analyze economic trends in real time.

## Visualizations
### Example 1: Inflation Trends Over Time
![Inflation Trends](visuals/basic/inflation_trends.png)

### Example 2: Regional Inflation Comparison (2000)
![Regional Comparison](visuals/advanced/cumulative_inflation.png)

---

## Data Sources
1. **OECD Statistics**: Consumer Price Indices (CPIs)
   - Dataset: [OECD Consumer Price Indices](https://stats.oecd.org)
2. **Global Inflation Data**
   - Dataset: Custom dataset containing inflation data by year and region.
3. **World Bank Data**
   - Dataset: [World Bank Inflation Data](https://data.worldbank.org/indicator/FP.CPI.TOTL.ZG)

---

## Author
Aurela Bytyci  
Master's Student in Data Science  
