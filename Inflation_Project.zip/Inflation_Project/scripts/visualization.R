# Load necessary libraries
library(ggplot2)
library(dplyr)
library(readr)

# Set working directory (Modify if needed)
setwd("~/Desktop/Inflation_Project")

# Load cleaned datasets
filtered_global <- read_csv("data/cleaned_global_inflation.csv")
filtered_wb <- read_csv("data/cleaned_world_bank_data.csv")

# Filter out extreme values for clarity
filtered_global <- filtered_global %>% filter(InflationRate >= 0 & InflationRate <= 100)
filtered_wb <- filtered_wb %>% filter(InflationRate >= 0 & InflationRate <= 100)

# Select top 10 countries with highest average inflation for better readability
top_countries <- filtered_wb %>% 
  group_by(`Country Name`) %>% 
  summarise(avg_inflation = mean(InflationRate, na.rm = TRUE)) %>% 
  arrange(desc(avg_inflation)) %>% 
  head(10) %>% 
  pull(`Country Name`)

filtered_wb_top <- filtered_wb %>% filter(`Country Name` %in% top_countries)

# Ensure the directory exists
dir.create("visuals/basic", recursive = TRUE, showWarnings = FALSE)

# 1. Inflation Trends Over Time
inflation_trends <- ggplot(filtered_wb_top, aes(x = Year, y = InflationRate, color = `Country Name`, group = `Country Name`)) +
  geom_line(size = 1.2) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Inflation Trends Over Time (Top 10 Countries)",
    x = "Year",
    y = "Inflation Rate (%)",
    color = "Country"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    legend.position = "right",
    panel.grid.major = element_line(size = 0.5, linetype = "dotted")
  )

ggsave("visuals/basic/inflation_trends.png", inflation_trends, width = 10, height = 6)

# 2. Inflation Histogram
inflation_histogram <- ggplot(filtered_wb, aes(x = InflationRate)) +
  geom_histogram(binwidth = 5, fill = "blue", color = "black", alpha = 0.8, na.rm = TRUE) + 
  scale_x_continuous(limits = c(0, 100), breaks = seq(0, 100, 10)) + 
  scale_y_continuous(expand = c(0, 0)) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Distribution of Inflation Rates",
    x = "Inflation Rate (%)",
    y = "Frequency"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text = element_text(size = 12),
    axis.title = element_text(size = 14)
  )

ggsave("visuals/basic/inflation_histogram.png", inflation_histogram, width = 10, height = 6)

# 3. Inflation Pie Chart (for Year 2000)
filtered_2000 <- filtered_wb %>% filter(Year == 2000)

inflation_pie_chart <- ggplot(filtered_2000, aes(x = "", y = InflationRate, fill = `Country Name`)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  theme_void() +
  labs(title = "Inflation Rate Distribution (Year 2000)") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold"))

ggsave("visuals/basic/inflation_pie_chart.png", inflation_pie_chart, width = 10, height = 6)

# 4. Bar Chart of Inflation by Region (2000)
inflation_bar_chart <- ggplot(filtered_2000, aes(x = `Country Name`, y = InflationRate, fill = `Country Name`)) +
  geom_bar(stat = "identity") +
  theme_minimal(base_size = 14) +
  labs(
    title = "Inflation Rate by Country (2000)",
    x = "Country",
    y = "Inflation Rate (%)"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

ggsave("visuals/basic/inflation_bar_chart.png", inflation_bar_chart, width = 10, height = 6)

message("All visualizations saved in 'visuals/clean/'\n")
