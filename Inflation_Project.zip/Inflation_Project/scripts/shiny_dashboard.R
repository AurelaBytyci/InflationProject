# Load necessary libraries
library(shiny)
library(ggplot2)
library(dplyr)
library(readr)

# Load cleaned data
data_path <- file.path("data", "cleaned_global_inflation.csv")  
global_data <- read_csv("../data/cleaned_global_inflation.csv")


# Define UI
ui <- fluidPage(
  titlePanel("Interactive Inflation Dashboard"),
  sidebarLayout(
    sidebarPanel(
      selectInput("country", "Select a Country", choices = unique(global_data$country_name))
    ),
    mainPanel(
      plotOutput("trendPlot")
    )
  )
)

# Define Server
server <- function(input, output) {
  output$trendPlot <- renderPlot({
    ggplot(global_data %>% filter(country_name == input$country & InflationRate > 1), 
           aes(x = Year, y = InflationRate)) +
      geom_line(color = "blue", size = 1.2) +
      labs(title = paste("Inflation Trends for", input$country), 
           x = "Year", y = "Inflation Rate (%)") +
      theme_minimal()
  })
}

# Run the App
shinyApp(ui, server)