# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)

# Set working directory (Modify if needed)
setwd("~/Desktop/Inflation_Project")

# ------------------------- #
# Load and Clean Global Inflation Data #
# ------------------------- #

# Load Global Inflation dataset
global_data <- read_csv("data/cleaned_global_inflation.csv")

# Calculate average inflation per country and filter top 10 countries
top_countries <- global_data %>%
  group_by(country_name) %>%
  summarize(avg_inflation = mean(InflationRate, na.rm = TRUE)) %>%
  arrange(desc(avg_inflation)) %>%
  head(10) %>% pull(country_name)

# Keep only the top 10 countries for better visualization
cleaned_global <- global_data %>%
  filter(country_name %in% top_countries & InflationRate >= 1 & InflationRate <= 1000)

# Save cleaned global inflation dataset
write_csv(cleaned_global, "data/cleaned_global_inflation.csv")
cat("✅ Global Inflation dataset cleaned and saved.\n")

# ------------------------------ #
# Load and Clean World Bank Data #
# ------------------------------ #

# Load World Bank dataset
wb_data <- read_csv("data/cleaned_world_bank_data.csv")

# Keep only the top 10 countries from global inflation data
cleaned_wb <- wb_data %>%
  filter(`Country Name` %in% top_countries & InflationRate >= 1 & InflationRate <= 1000)

# Save cleaned world bank dataset
write_csv(cleaned_wb, "data/cleaned_world_bank_data.csv")
message("✅ World Bank dataset cleaned and saved.\n")

message("🚀 Data cleaning process completed successfully!\n")
